
declare module '*.css';
declare module '*.less';
declare module '*.png';
declare module '*.js';
declare module '*.json';
declare module '*.gif';
declare module '*.webp';

type Student = {
    name: string;
    age: number;
    hobby?: string[];
}