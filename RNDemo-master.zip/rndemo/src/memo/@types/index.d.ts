type UserInfo = {
    avatar: string;
    name: string;
    desc: string;
}