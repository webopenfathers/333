package com.demo.newarchitecture.view;

import android.content.Context;
import android.widget.LinearLayout;

public class InfoViewGroup extends LinearLayout {
    public InfoViewGroup(Context context) {
        super(context);
    }
}
